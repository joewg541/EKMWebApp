﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ekm_mvc_webapp.Migrations
{
    public partial class ProductMigrationUpdated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
