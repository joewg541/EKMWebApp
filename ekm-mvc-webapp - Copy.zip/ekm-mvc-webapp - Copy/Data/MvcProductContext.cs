using Microsoft.EntityFrameworkCore;
using ekm_mvc_webapp.Models;

namespace ekm_mvc_webapp.Data
{
    public class MvcProductContext : DbContext
    {
        public MvcProductContext (DbContextOptions<MvcProductContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
    }
}