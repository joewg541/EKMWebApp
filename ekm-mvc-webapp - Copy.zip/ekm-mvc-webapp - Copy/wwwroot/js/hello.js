class HelloWorld extends React.Component {
    render() {
        return <div>Hello World</div>;
    }
  }
  
  const containerElement = document.getElementById('content');
  ReactDOM.render(<HelloWorld />, containerElement);