using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ekm_mvc_webapp.Models
{
    public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdProduct { get; set; }

        [Display(Name = "Enter Product Code")]
        [StringLength(20)]
        [Required(ErrorMessage = "{0} Is required.")]
        public string ProductCode { get; set; }
        
        [Display(Name = "Enter Product Type")]
        [StringLength(50)]
        [Required(ErrorMessage = "{0} Is required.")]
        public string ProductType { get; set; }
        
        [Display(Name = "Enter Product Description")]
        [StringLength(150)]
        public string Description { get; set; }
        
        [Display(Name = "Enter Product Price")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        [Required(ErrorMessage = "{0} is required.")]
        public decimal UnitPrice { get; set; }
        
        [Display(Name = "Select an Image")]
        public string ImagePath {get; set; }

    }

}